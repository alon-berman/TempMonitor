def save_to_file(content, file_name, ext, bytes_chunk=None):
    pass