class AbsMeasurementHandler:
    def __init__(self, threshold=None):
        pass

    def check_measurement(self):
        pass

    def get_latest_measurement(self):
        pass

    def get_measurement_buffer(self):
        pass
