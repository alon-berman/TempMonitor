
class AbsCloudObj:
    def __init__(self):
        pass

    def get_cloud_data(self):
        pass