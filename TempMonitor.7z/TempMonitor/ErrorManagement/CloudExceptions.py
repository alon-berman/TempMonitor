class BaseCloudException(Exception):
    pass


class CloudNoDataException(BaseCloudException):
    pass
