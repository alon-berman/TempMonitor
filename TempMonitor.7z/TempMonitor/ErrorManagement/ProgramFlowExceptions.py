
class SoupMissingException(BaseException):
    pass


class Data(BaseException):
    pass
